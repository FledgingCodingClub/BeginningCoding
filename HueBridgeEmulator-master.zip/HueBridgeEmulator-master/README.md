## HueBridgeEmulator

This is a lite version of my DiyHue project, i remove all functions that manage wifi lights and sensors. This is intended just to test Hue apps without a real Philips Hue Bridge.
Very usefull to understand how bridge process rules. 
Edit config.json to add more lights or sesors.
